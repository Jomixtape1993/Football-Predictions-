import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Calendar, TrendingUp, Users, AlertTriangle, Trophy, Target, BarChart3, Activity } from 'lucide-react'
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import './App.css'

function App() {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0])
  const [predictions, setPredictions] = useState([])
  const [loading, setLoading] = useState(false)

  // Dados de exemplo para demonstração
  const samplePredictions = [
    {
      id: 1,
      equipa_casa: 'SL Benfica',
      equipa_fora: 'FC Porto',
      previsao_principal: 'Vitória SL Benfica',
      confianca: 53.7,
      probabilidades: {
        vitoria_casa: 53.7,
        empate: 9.6,
        vitoria_fora: 36.7
      },
      analise_detalhada: {
        forca_equipa_casa: 0.357,
        forca_equipa_fora: 0.407,
        impacto_jogadores_casa: 0.500,
        impacto_jogadores_fora: 0.500,
        impacto_lesoes_casa: 1.000,
        impacto_lesoes_fora: 0.760,
        fator_casa: 1.000,
        fator_fora: 0.075,
        fator_confrontos_diretos_casa: 0.925,
        fator_confrontos_diretos_fora: 0.075
      },
      pontuacao_final: {
        casa: 0.756,
        fora: 0.544
      }
    },
    {
      id: 2,
      equipa_casa: 'Sporting CP',
      equipa_fora: 'SC Braga',
      previsao_principal: 'Vitória Sporting CP',
      confianca: 48.2,
      probabilidades: {
        vitoria_casa: 48.2,
        empate: 26.3,
        vitoria_fora: 25.5
      },
      analise_detalhada: {
        forca_equipa_casa: 0.420,
        forca_equipa_fora: 0.380,
        impacto_jogadores_casa: 0.650,
        impacto_jogadores_fora: 0.580,
        impacto_lesoes_casa: 0.900,
        impacto_lesoes_fora: 0.950,
        fator_casa: 0.600,
        fator_fora: 0.400,
        fator_confrontos_diretos_casa: 0.550,
        fator_confrontos_diretos_fora: 0.450
      },
      pontuacao_final: {
        casa: 0.624,
        fora: 0.552
      }
    }
  ]

  const teamStats = [
    { name: 'SL Benfica', golos_marcados: 2.1, golos_sofridos: 0.8, clean_sheets: 65 },
    { name: 'FC Porto', golos_marcados: 1.9, golos_sofridos: 0.9, clean_sheets: 58 },
    { name: 'Sporting CP', golos_marcados: 2.3, golos_sofridos: 1.1, clean_sheets: 52 },
    { name: 'SC Braga', golos_marcados: 1.7, golos_sofridos: 1.0, clean_sheets: 48 }
  ]

  const injuries = [
    { team: 'FC Porto', player: 'Pepe', position: 'Defesa Central', injury: 'Muscular', severity: 'Moderada', impact: 4 },
    { team: 'Sporting CP', player: 'Morten Hjulmand', position: 'Médio Defensivo', injury: 'Ligamentar', severity: 'Ligeira', impact: 3 },
    { team: 'SC Braga', player: 'Ricardo Horta', position: 'Extremo', injury: 'Contusão', severity: 'Ligeira', impact: 2 }
  ]

  useEffect(() => {
    // Simular carregamento de dados
    setLoading(true)
    setTimeout(() => {
      setPredictions(samplePredictions)
      setLoading(false)
    }, 1000)
  }, [selectedDate])

  const getConfidenceColor = (confidence) => {
    if (confidence >= 60) return 'text-green-600'
    if (confidence >= 40) return 'text-yellow-600'
    return 'text-red-600'
  }

  const getConfidenceBadgeVariant = (confidence) => {
    if (confidence >= 60) return 'default'
    if (confidence >= 40) return 'secondary'
    return 'destructive'
  }

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'Ligeira': return 'bg-yellow-100 text-yellow-800'
      case 'Moderada': return 'bg-orange-100 text-orange-800'
      case 'Grave': return 'bg-red-100 text-red-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const PredictionCard = ({ prediction }) => {
    const chartData = [
      { name: 'Casa', value: prediction.probabilidades.vitoria_casa, color: '#22c55e' },
      { name: 'Empate', value: prediction.probabilidades.empate, color: '#f59e0b' },
      { name: 'Fora', value: prediction.probabilidades.vitoria_fora, color: '#ef4444' }
    ]

    return (
      <Card className="w-full">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-xl font-bold">
              {prediction.equipa_casa} vs {prediction.equipa_fora}
            </CardTitle>
            <Badge variant={getConfidenceBadgeVariant(prediction.confianca)}>
              {prediction.confianca}% confiança
            </Badge>
          </div>
          <CardDescription className="text-lg font-semibold">
            Previsão: <span className={getConfidenceColor(prediction.confianca)}>
              {prediction.previsao_principal}
            </span>
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Gráfico de Probabilidades */}
            <div>
              <h4 className="font-semibold mb-3">Probabilidades</h4>
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie
                    data={chartData}
                    cx="50%"
                    cy="50%"
                    innerRadius={40}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {chartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => `${value}%`} />
                </PieChart>
              </ResponsiveContainer>
              <div className="flex justify-center space-x-4 mt-2">
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-green-500 rounded mr-1"></div>
                  <span className="text-sm">Casa {prediction.probabilidades.vitoria_casa}%</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-yellow-500 rounded mr-1"></div>
                  <span className="text-sm">Empate {prediction.probabilidades.empate}%</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-red-500 rounded mr-1"></div>
                  <span className="text-sm">Fora {prediction.probabilidades.vitoria_fora}%</span>
                </div>
              </div>
            </div>

            {/* Análise Detalhada */}
            <div>
              <h4 className="font-semibold mb-3">Análise Detalhada</h4>
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Força da Equipa</span>
                    <span>{(prediction.analise_detalhada.forca_equipa_casa * 100).toFixed(1)}% vs {(prediction.analise_detalhada.forca_equipa_fora * 100).toFixed(1)}%</span>
                  </div>
                  <Progress value={prediction.analise_detalhada.forca_equipa_casa * 100} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Impacto Jogadores</span>
                    <span>{(prediction.analise_detalhada.impacto_jogadores_casa * 100).toFixed(1)}% vs {(prediction.analise_detalhada.impacto_jogadores_fora * 100).toFixed(1)}%</span>
                  </div>
                  <Progress value={prediction.analise_detalhada.impacto_jogadores_casa * 100} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Impacto Lesões</span>
                    <span>{(prediction.analise_detalhada.impacto_lesoes_casa * 100).toFixed(1)}% vs {(prediction.analise_detalhada.impacto_lesoes_fora * 100).toFixed(1)}%</span>
                  </div>
                  <Progress value={prediction.analise_detalhada.impacto_lesoes_casa * 100} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Fator Casa/Fora</span>
                    <span>{(prediction.analise_detalhada.fator_casa * 100).toFixed(1)}% vs {(prediction.analise_detalhada.fator_fora * 100).toFixed(1)}%</span>
                  </div>
                  <Progress value={prediction.analise_detalhada.fator_casa * 100} className="h-2" />
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2 flex items-center justify-center gap-2">
            <Trophy className="h-8 w-8 text-yellow-600" />
            Analisador Profissional de Apostas de Futebol
          </h1>
          <p className="text-lg text-gray-600">
            Análise baseada em dados de desempenho, lesões e histórico de confrontos
          </p>
        </div>

        {/* Date Selector */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Selecionar Data para Análise
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-4">
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <Button onClick={() => setSelectedDate(new Date().toISOString().split('T')[0])}>
                Hoje
              </Button>
              <Button 
                variant="outline" 
                onClick={() => {
                  const tomorrow = new Date()
                  tomorrow.setDate(tomorrow.getDate() + 1)
                  setSelectedDate(tomorrow.toISOString().split('T')[0])
                }}
              >
                Amanhã
              </Button>
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="predictions" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="predictions" className="flex items-center gap-2">
              <Target className="h-4 w-4" />
              Previsões
            </TabsTrigger>
            <TabsTrigger value="stats" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              Estatísticas
            </TabsTrigger>
            <TabsTrigger value="injuries" className="flex items-center gap-2">
              <AlertTriangle className="h-4 w-4" />
              Lesões
            </TabsTrigger>
            <TabsTrigger value="analysis" className="flex items-center gap-2">
              <Activity className="h-4 w-4" />
              Análise
            </TabsTrigger>
          </TabsList>

          <TabsContent value="predictions" className="mt-6">
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold">Previsões para {selectedDate}</h2>
                {loading && <div className="text-blue-600">A carregar...</div>}
              </div>
              
              {predictions.length === 0 && !loading ? (
                <Card>
                  <CardContent className="text-center py-8">
                    <p className="text-gray-500">Nenhum jogo agendado para esta data.</p>
                  </CardContent>
                </Card>
              ) : (
                predictions.map((prediction) => (
                  <PredictionCard key={prediction.id} prediction={prediction} />
                ))
              )}
            </div>
          </TabsContent>

          <TabsContent value="stats" className="mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5" />
                    Desempenho das Equipas
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={teamStats}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" angle={-45} textAnchor="end" height={80} />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="golos_marcados" fill="#22c55e" name="Golos Marcados" />
                      <Bar dataKey="golos_sofridos" fill="#ef4444" name="Golos Sofridos" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Clean Sheets (%)</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {teamStats.map((team) => (
                      <div key={team.name}>
                        <div className="flex justify-between text-sm mb-1">
                          <span>{team.name}</span>
                          <span>{team.clean_sheets}%</span>
                        </div>
                        <Progress value={team.clean_sheets} className="h-2" />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="injuries" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5" />
                  Relatório de Lesões
                </CardTitle>
                <CardDescription>
                  Jogadores atualmente lesionados que podem afetar as previsões
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {injuries.map((injury, index) => (
                    <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                      <div>
                        <h4 className="font-semibold">{injury.player}</h4>
                        <p className="text-sm text-gray-600">{injury.team} - {injury.position}</p>
                        <p className="text-sm">{injury.injury}</p>
                      </div>
                      <div className="text-right">
                        <Badge className={getSeverityColor(injury.severity)}>
                          {injury.severity}
                        </Badge>
                        <p className="text-sm mt-1">Impacto: {injury.impact}/5</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analysis" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Ponderações do Modelo</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Desempenho Equipa:</span>
                      <span className="font-semibold">40%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Desempenho Jogadores:</span>
                      <span className="font-semibold">25%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Lesões:</span>
                      <span className="font-semibold">15%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Confrontos Diretos:</span>
                      <span className="font-semibold">10%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Fator Casa/Fora:</span>
                      <span className="font-semibold">10%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Métricas Analisadas</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-1 text-xs">
                    <p>• Golos marcados/sofridos</p>
                    <p>• Remates à baliza</p>
                    <p>• Posse de bola</p>
                    <p>• Clean sheets</p>
                    <p>• Cartões amarelos/vermelhos</p>
                    <p>• Desempenho casa/fora</p>
                    <p>• Histórico confrontos</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Dados dos Jogadores</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-1 text-xs">
                    <p>• Golos e assistências</p>
                    <p>• Minutos jogados</p>
                    <p>• Remates e passes</p>
                    <p>• Desarmes e interceções</p>
                    <p>• Cartões disciplinares</p>
                    <p>• Últimos 20 jogos</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Validação</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-1 text-xs">
                    <p>• Backtesting histórico</p>
                    <p>• Comparação com odds</p>
                    <p>• Monitorização tempo real</p>
                    <p>• Métricas de precisão</p>
                    <p>• Ajustes automáticos</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Como Funciona a Análise</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="prose max-w-none">
                  <p className="mb-4">
                    O nosso sistema de análise profissional utiliza um algoritmo avançado que combina múltiplos fatores 
                    para gerar previsões precisas:
                  </p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-semibold mb-2">1. Análise de Desempenho (40%)</h4>
                      <p className="text-sm text-gray-600 mb-4">
                        Avaliamos o desempenho recente das equipas nos últimos 5-10 jogos, incluindo golos marcados/sofridos, 
                        remates à baliza, posse de bola e disciplina.
                      </p>

                      <h4 className="font-semibold mb-2">2. Impacto dos Jogadores (25%)</h4>
                      <p className="text-sm text-gray-600 mb-4">
                        Analisamos o desempenho individual dos jogadores chave nos últimos 20 jogos, considerando 
                        golos, assistências, passes e contribuição defensiva.
                      </p>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-2">3. Relatório de Lesões (15%)</h4>
                      <p className="text-sm text-gray-600 mb-4">
                        Avaliamos o impacto das lesões atuais, considerando a importância dos jogadores lesionados 
                        e a qualidade dos substitutos disponíveis.
                      </p>

                      <h4 className="font-semibold mb-2">4. Fatores Adicionais (20%)</h4>
                      <p className="text-sm text-gray-600">
                        Incluímos o histórico de confrontos diretos (10%) e o fator casa/fora (10%) para 
                        uma análise mais completa e contextualizada.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

export default App

